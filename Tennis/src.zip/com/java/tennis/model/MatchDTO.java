package com.java.tennis.model;

public class MatchDTO {
	private int no;					//일련번호
}
