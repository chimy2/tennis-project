package com.java.tennis.model;

public class GameDTO {
	private int no;					//일련번호
}
