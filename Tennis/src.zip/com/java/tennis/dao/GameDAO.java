package com.java.tennis.dao;

public class GameDAO {
}
