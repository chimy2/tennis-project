package com.java.tennis.service;

public class GameService {
}
