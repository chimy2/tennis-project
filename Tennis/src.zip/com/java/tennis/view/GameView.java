package com.java.tennis.view;

import com.java.tennis.model.CharacterDTO;

public class GameView {
	
	CharacterDTO dto = new CharacterDTO();
	
	public void gameView(CharacterDTO dtoCharacter) {
		
		int i = Integer.parseInt(dtoCharacter.getNo());
		
		String temp = "";
		
		if (i == 1) {
			temp += "어떤 스킬을 사용하겠습니까?\r\n";
			temp += "1. 슈퍼서브!\r\n";
			temp += "2. 포핸드\r\n";
			temp += "3. 백핸드\r\n";
			temp += "4. 발리\r\n";
			System.out.println(temp);
			
		} else if (i == 2) {
			temp += "어떤 스킬을 사용하겠습니까?\r\n";
			temp += "1. 서브\r\n";
			temp += "2. 슈퍼포핸드!\r\n";
			temp += "3. 백핸드\r\n";
			temp += "4. 발리\r\n";
			System.out.println(temp);
			
		} else if (i == 3) {
			temp += "어떤 스킬을 사용하겠습니까?\r\n";
			temp += "1. 서브\r\n";
			temp += "2. 포핸드\r\n";
			temp += "3. 슈퍼백핸드!\r\n";
			temp += "4. 발리\r\n";
			System.out.println(temp);
			
		} else if (i == 4) {
			temp += "어떤 스킬을 사용하겠습니까?\r\n";
			temp += "1. 서브\r\n";
			temp += "2. 포핸드\r\n";
			temp += "3. 백핸드\r\n";
			temp += "4. 슈퍼발리!\r\n";
			System.out.println(temp);
		}
		

		
		
		}
	}

