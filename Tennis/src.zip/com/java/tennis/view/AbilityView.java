package com.java.tennis.view;

public class AbilityView {
}
