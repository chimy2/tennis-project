package com.java.tennis.view;

import java.util.Scanner;


public class CharacterView {

	
	Scanner scan = new Scanner(System.in);
	
	
	
}
